import pandas as pd
import matplotlib.pyplot as plt

# ==========================
# Read original Excel file
df = pd.read_excel("Clean_Data.xlsx")

clean_data = df.dropna()
print(df[df.duplicated()])
# ========================== CHANGE DATE INTO PYTHON DATE FORMAT
df["signup_date"] = pd.to_datetime(df["signup_date"])
#===================MIN.MAX
# print(df["satisfaction_score"].min() , df["satisfaction_score"].max())

# ==========================average customer spending & median ===grouping params
average_customer_spending = df["total_spending"].mean()
spending_median = df["total_spending"].median()
#print("Average customer spending:", average_customer_spending)
# ==========================average order 
average_order_value = df["avg_order_value"].mean()

#print("Average order value:", average_order_value)
# ==========================
average_satisfaction = df["satisfaction_score"].mean()
satisfaction_median = df["satisfaction_score"].median()
#print("Average satisfaction:", average_satisfaction)
# ==========================
return_rate = (
    df["returned_items"].sum() / df["purchase_count"].sum()
) * 100

#print("Return Rate:", return_rate)
# ==========================calculate median for grouping customers
purchase_median = df["purchase_count"].median()

#=========================================== segmenting customer by labeling 
df["segment"] = "Needs Attention"

df.loc[
    (df["total_spending"] >= spending_median) &
    (df["last_purchase_days"] > 180),
    "segment"
] = "At Risk"
df.loc[
    (df["total_spending"] >= spending_median) &
    (df["purchase_count"] >= purchase_median) &
    (df["last_purchase_days"] <= 100) ,
    "segment"
] = "Champions"
df.loc[
    (df["purchase_count"] >= purchase_median) &
    (df["last_purchase_days"] <= 180) &
    (df["last_purchase_days"] > 100),
    "segment"
] = "Loyal Customers"
print(df[[
    "customer_id",
    "total_spending",
    "purchase_count",
    "last_purchase_days",
    "satisfaction_score",
    "membership_tier",
    "segment"
]])
print(df["segment"].value_counts())
df.groupby("segment")["avg_order_value"].mean()

#============================ 
order_average = df["avg_order_value"].mean()

# print(
#     (df["avg_order_value"] > order_average).sum()
# )
# df.groupby("segment")["avg_order_value"].agg(
#     ["mean", "median", "min", "max"]
# )
#================= average calculation through each segment
# segment_analysis = df.groupby("segment").agg(
#     customer_count=("customer_id", "count"),
#     avg_spending=("total_spending", "mean"),
#     avg_purchases=("purchase_count", "mean"),
#     avg_recency=("last_purchase_days", "mean"),
#     avg_order_value=("avg_order_value", "mean")
# )

# print(segment_analysis)
#===============================choosing 10 best customers , eligible for average order value and membership
aov_median = df["avg_order_value"].median()
top_candidates = df.loc[
    (df["segment"].isin(["Loyal Customers", "Champions"])) &
    (df["avg_order_value"] > aov_median)
]
top_10 = top_candidates.sort_values(
    "total_spending",
    ascending=False
).head(10)

print(
    top_10[
        [
            "customer_id",
            "first_name",
            "membership_tier",
            "segment",
            "purchase_count",
            "avg_order_value",
            "total_spending",
            "last_purchase_days"
        ]
    ]
)
#================== plotting


aov_median = df["avg_order_value"].median()

# مشتری‌های Champion و Loyal
eligible = df[
    df["segment"].isin(["Champions", "Loyal Customers"])
]

# کاندیداهای نهایی
top_candidates = eligible[
    eligible["avg_order_value"] > aov_median
].sort_values(
    "total_spending",
    ascending=False
).head(10)

#=============================== pareto rule
#1
df_pareto = df.sort_values("total_spending", ascending=False).copy()

df_pareto["cumulative_revenue"] = df_pareto["total_spending"].cumsum()

total_revenue = df_pareto["total_spending"].sum()

n_top_20 = int(len(df_pareto) * 0.20)

top_20_revenue_pct = (
    df_pareto.iloc[:n_top_20]["total_spending"].sum()
    / total_revenue * 100
)


df_pareto["cumulative_revenue_pct"] = (
    df_pareto["cumulative_revenue"] / total_revenue * 100
)

print("Number of customers:", len(df))
print("Top 20% customers:", n_top_20)
print("Revenue share of top 20%:",
      round(top_20_revenue_pct, 2), "%")

#==============
import matplotlib.pyplot as plt

customer_rank = range(1, len(df_pareto) + 1)

plt.figure(figsize=(10, 6))

plt.bar(
    customer_rank,
    df_pareto["total_spending"]
)

plt.xlabel("Customer Rank")
plt.ylabel("Total Spending")
plt.title("Pareto Analysis of Customer Revenue")

plt.twinx().plot(
    customer_rank,
    df_pareto["cumulative_revenue_pct"],
    marker="o"
)

plt.ylabel("Cumulative Revenue (%)")

plt.axhline(
    80,
    linestyle="--"
)

plt.tight_layout()
plt.show()

#============ discount analysis
discount_plot = df.groupby("discount_used")[
    ["total_spending", "avg_order_value"]
].mean()

discount_plot.index = [
    "No Discount",
    "Used Discount"
]

discount_plot.plot(
    kind="bar",
    figsize=(8, 5)
)

plt.title("Customers With vs Without Discount")
plt.xlabel("Discount Usage")
plt.ylabel("Average Value")
plt.xticks(rotation=0)
plt.legend(["Average Total Spending", "Average Order Value"])

plt.tight_layout()
plt.show()