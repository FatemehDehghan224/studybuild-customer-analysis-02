import pandas as pd
import matplotlib.pyplot as plt
import pandas as np

# ==========================
# Read original Excel file
df = pd.read_excel("Clean_Data.xlsx")

clean_data = df.dropna()
print(df[df.duplicated()])
# ========================== CHANGE DATE INTO PYTHON DATE FORMAT
df["signup_date"] = pd.to_datetime(df["signup_date"])
#===================MIN.MAX
# print(df["satisfaction_score"].min() , df["satisfaction_score"].max())

# ==========================average customer spending & median ===grouping params
average_customer_spending = df["total_spending"].mean()
spending_median = df["total_spending"].median()
#print("Average customer spending:", average_customer_spending)
# ==========================average order 
average_order_value = df["avg_order_value"].mean()

#print("Average order value:", average_order_value)
# ==========================
average_satisfaction = df["satisfaction_score"].mean()
satisfaction_median = df["satisfaction_score"].median()
#print("Average satisfaction:", average_satisfaction)
# ==========================
return_rate = (
    df["returned_items"].sum() / df["purchase_count"].sum()
) * 100

#print("Return Rate:", return_rate)
# ==========================calculate median for grouping customers
purchase_median = df["purchase_count"].median()

# print("Spending Median:", spending_median)
# print("Purchase Count Median:", purchase_median)
# print("Satisfaction Median:", satisfaction_median)
# print("Average customer spending:", average_customer_spending)
# print("average order value:", average_order_value)
# print("Satisfaction Median:", satisfaction_median)
# print("return rate: ",return_rate)
# #=====================================
# print("count_lower_avg_order_value:",(df["avg_order_value"]<average_order_value).sum())


#=========================================== segmenting customer by labeling 


df["segment"] = "Needs Attention"


df.loc[
    (df["total_spending"] >= spending_median) &
    (df["last_purchase_days"] > 180),
    "segment"
] = "At Risk"


df.loc[
    (df["total_spending"] >= spending_median) &
    (df["purchase_count"] >= purchase_median) &
    (df["last_purchase_days"] <= 100) ,
    "segment"
] = "Champions"


df.loc[
    (df["purchase_count"] >= purchase_median) &
    (df["last_purchase_days"] <= 180) &
    (df["last_purchase_days"] > 100),
    "segment"
] = "Loyal Customers"


print(df[[
    "customer_id",
    "total_spending",
    "purchase_count",
    "last_purchase_days",
    "satisfaction_score",
    "membership_tier",
    "segment"
]])
print(df["segment"].value_counts())
df.groupby("segment")["avg_order_value"].mean()

#============================ 
# order_average = df["avg_order_value"].mean()

# print(
#     (df["avg_order_value"] > order_average).sum()
# )
# df.groupby("segment")["avg_order_value"].agg(
#     ["mean", "median", "min", "max"]
# )
#================= average calculation through each segment
# segment_analysis = df.groupby("segment").agg(
#     customer_count=("customer_id", "count"),
#     avg_spending=("total_spending", "mean"),
#     avg_purchases=("purchase_count", "mean"),
#     avg_recency=("last_purchase_days", "mean"),
#     avg_order_value=("avg_order_value", "mean")
# )

# print(segment_analysis)
#===============================choosing 10 best customers , eligible for average order value and membership
aov_median = df["avg_order_value"].median()
top_candidates = df.loc[
    (df["segment"].isin(["Loyal Customers", "Champions"])) &
    (df["avg_order_value"] > aov_median)
]
top_10 = top_candidates.sort_values(
    "total_spending",
    ascending=False
).head(10)

print(
    top_10[
        [
            "customer_id",
            "first_name",
            "membership_tier",
            "segment",
            "purchase_count",
            "avg_order_value",
            "total_spending",
            "last_purchase_days"
        ]
    ]
)
#================== plotting


aov_median = df["avg_order_value"].median()

# مشتری‌های Champion و Loyal
eligible = df[
    df["segment"].isin(["Champions", "Loyal Customers"])
]

# کاندیداهای نهایی
top_candidates = eligible[
    eligible["avg_order_value"] > aov_median
].sort_values(
    "total_spending",
    ascending=False
).head(10)


# plt.figure(figsize=(10, 6))

# # همه مشتری‌های Champion و Loyal
# plt.scatter(
#     eligible["avg_order_value"],
#     eligible["total_spending"],
#     label="Champions / Loyal"
# )

# # مشتری‌های انتخاب‌شده
# plt.scatter(
#     top_candidates["avg_order_value"],
#     top_candidates["total_spending"],
#     marker="*",
#     s=180,
#     label="Selected Customers"
# )

# # خط Median AOV
# plt.axvline(
#     aov_median,
#     linestyle="--",
#     label=f"Median AOV = {aov_median:.2f}"
# )

# plt.xlabel("Average Order Value")
# plt.ylabel("Total Spending")
# plt.title("Selected Customers for Discount Campaign")

# plt.legend()
# plt.tight_layout()
# plt.show()
#=============================== best town
city_analysis = df.groupby("city").agg(
    customer_count=("customer_id", "count"),
    total_revenue=("total_spending", "sum"),
    avg_spending=("total_spending", "mean"),
    avg_order_value=("avg_order_value", "mean"),
    avg_satisfaction=("satisfaction_score", "mean"),
    avg_returns=("returned_items", "mean"),
    avg_recency=("last_purchase_days", "mean")
).sort_values("total_revenue", ascending=False)

print(city_analysis)
#=================================


# مرتب کردن شهرها بر اساس درآمد کل
city_plot = city_analysis.sort_values(
    "total_revenue",
    ascending=False
).copy()

# نرمال‌سازی به بازه 0 تا 100
columns = [
    "total_revenue",
    "avg_spending",
    "avg_order_value",
    "avg_satisfaction"
]

scaled = city_plot[columns].copy()

for col in columns:
    min_value = scaled[col].min()
    max_value = scaled[col].max()

    scaled[col] = (
        (scaled[col] - min_value)
        / (max_value - min_value)
        * 100
    )

# رسم نمودار
plt.figure(figsize=(12, 6))

plt.plot(
    scaled.index,
    scaled["total_revenue"],
    marker="o",
    label="Total Revenue"
)

plt.plot(
    scaled.index,
    scaled["avg_spending"],
    marker="o",
    label="Average Spending"
)

plt.plot(
    scaled.index,
    scaled["avg_order_value"],
    marker="o",
    label="Average Order Value"
)

plt.plot(
    scaled.index,
    scaled["avg_satisfaction"],
    marker="o",
    label="Average Satisfaction"
)

plt.xlabel("City")
plt.ylabel("Relative Value (0-100)")
plt.title("City Comparison")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()

plt.show()

#============= compare big cities

import matplotlib.pyplot as plt

# شهرهای موردنظر
selected_cities = [
    "Mashhad",
    "Tabriz",
    "Tehran",
    "Isfahan"
]

# ساخت جدول
city_comparison = df[
    df["city"].isin(selected_cities)
].groupby("city").agg(
    customer_count=("customer_id", "count"),
    avg_order_value=("avg_order_value", "mean"),
    avg_satisfaction=("satisfaction_score", "mean"),
    avg_recency=("last_purchase_days", "mean")
)

#
scaled_city = city_comparison.copy()

# -----------------------------
# Normalization: 0 تا 100
# -----------------------------

columns = [
    "customer_count",
    "avg_order_value",
    "avg_satisfaction"
]

for col in columns:
    min_value = scaled_city[col].min()
    max_value = scaled_city[col].max()

    scaled_city[col] = (
        (scaled_city[col] - min_value)
        / (max_value - min_value)
        * 100
    )

# -----------------------------
# Recency

# -----------------------------

min_recency = scaled_city["avg_recency"].min()
max_recency = scaled_city["avg_recency"].max()

scaled_city["avg_recency"] = (
    (max_recency - scaled_city["avg_recency"])
    / (max_recency - min_recency)
    * 100
)

# -----------------------------
# Plot
# -----------------------------

plt.figure(
    num="Selected Cities Comparison",
    figsize=(11, 6)
)

plt.plot(
    scaled_city.index,
    scaled_city["customer_count"],
    marker="o",
    label="Customer Count"
)

plt.plot(
    scaled_city.index,
    scaled_city["avg_order_value"],
    marker="o",
    label="Average Order Value"
)

plt.plot(
    scaled_city.index,
    scaled_city["avg_satisfaction"],
    marker="o",
    label="Average Satisfaction"
)

plt.plot(
    scaled_city.index,
    scaled_city["avg_recency"],
    marker="o",
    label="Recency Performance"
)

plt.xlabel("City")
plt.ylabel("Relative Performance (0-100)")

plt.title(
    "Mashhad, Tabriz, Tehran and Rasht Comparison"
)

plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()

plt.show()
